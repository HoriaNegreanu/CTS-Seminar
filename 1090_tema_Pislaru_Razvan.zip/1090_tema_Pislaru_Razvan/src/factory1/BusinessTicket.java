package factory1;

public class BusinessTicket extends AbstractTicket{

	int loc;
	
	public BusinessTicket(String numePersoana, int loc) {
		super(numePersoana);
		this.loc = loc;
	}
	

	public int getLoc() {
		return loc;
	}

	public void setLoc(int loc) {
		this.loc = loc;
	}

	@Override
	public void getTicketInfo() {
		System.out.println("Acesta este un bilet de tip Business detinut de " + this.numePersoana);
	}

}
