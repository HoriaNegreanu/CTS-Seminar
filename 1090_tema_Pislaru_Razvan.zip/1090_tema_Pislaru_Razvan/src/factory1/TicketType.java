package factory1;

public enum TicketType {
	ECONOMIC, BUSINESS
}
