package factory1;

public class TicketFactory {

	public static AbstractTicket getTicket(TicketType type, String numePersoana) {
		
		switch(type) {
		case ECONOMIC:
			return new EconomicTicket(numePersoana, "");
		case BUSINESS:
			return new BusinessTicket(numePersoana, 0);
		default:
			throw new UnsupportedOperationException();
		}
	}
}
