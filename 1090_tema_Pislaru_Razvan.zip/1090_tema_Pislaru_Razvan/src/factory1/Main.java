package factory1;

public class Main {

	public static void main(String[] args) {
		
		AbstractTicket economicTicket = TicketFactory.getTicket(TicketType.ECONOMIC, "Ion Popescu");
		AbstractTicket businessTicket = TicketFactory.getTicket(TicketType.BUSINESS, "Elena Maria");
		
		economicTicket.getTicketInfo();
		businessTicket.getTicketInfo();

	}

}
