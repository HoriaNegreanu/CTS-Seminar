package factory1;

public abstract class AbstractTicket {
	
	String numePersoana;
	
	public AbstractTicket(String numePersoana) {
		super();
		this.numePersoana = numePersoana;
	}

	public abstract void getTicketInfo();
}
