package factory1;

public class EconomicTicket extends AbstractTicket{

	String zona;
	
	public EconomicTicket(String numePersoana, String zona) {
		super(numePersoana);
		this.zona = zona;
	}

	public String getZona() {
		return zona;
	}

	public void setZona(String zona) {
		this.zona = zona;
	}
	
	@Override
	public void getTicketInfo() {
		System.out.println("Acesta este un bilet de tip Economic detinut de " + this.numePersoana);
	}

}
