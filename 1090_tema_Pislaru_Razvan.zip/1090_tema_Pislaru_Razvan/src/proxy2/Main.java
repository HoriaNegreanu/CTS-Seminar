package proxy2;

public class Main {

	public static void main(String[] args) {
		Ticket ticket = new Ticket("Zbor SUA", 200);
		
		CancelInterface cancelModule = new CancelModule();
		if(cancelModule.cancelTicket(ticket)) {
			System.out.println("Biletul a fost anulat");
		}
		
		//adaugare proxy
		System.out.println("--------------");
		cancelModule = new CancelProxy(cancelModule);
		if(cancelModule.cancelTicket(ticket)) {
			System.out.println("Biletul a fost anulat");
		}
		else {
			System.out.println("Biletul nu a fost anulat");
		}
		
	}
}
