package proxy2;

public class CancelProxy implements CancelInterface{

	private CancelInterface cancelModule;

	public CancelProxy(CancelInterface cancelModule) {
		super();
		this.cancelModule = cancelModule;
	}

	@Override
	public boolean cancelTicket(Ticket ticket) {
		if(ticket.pret < 100) {
			return cancelModule.cancelTicket(ticket);
		}
		else {
			System.out.println("Anularea biletelor peste 100 de lei nu este gratuita");
			return false;
		}
	}
}
