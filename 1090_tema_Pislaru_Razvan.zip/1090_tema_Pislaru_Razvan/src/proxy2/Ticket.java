package proxy2;

public class Ticket {
	String numeZbor;
	float pret;
	
	public Ticket(String numeZbor, float pret) {
		super();
		this.numeZbor = numeZbor;
		this.pret = pret;
	}
}
