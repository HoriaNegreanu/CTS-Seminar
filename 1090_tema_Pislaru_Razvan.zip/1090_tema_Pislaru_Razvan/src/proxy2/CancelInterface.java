package proxy2;

public interface CancelInterface {
	
	public abstract boolean cancelTicket(Ticket ticket);
}
