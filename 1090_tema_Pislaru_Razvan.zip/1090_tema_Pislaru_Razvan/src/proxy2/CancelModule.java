package proxy2;

public class CancelModule implements CancelInterface{

	@Override
	public boolean cancelTicket(Ticket ticket) {
		System.out.println("Anularea este gratuita");
		return true;
	}

}
